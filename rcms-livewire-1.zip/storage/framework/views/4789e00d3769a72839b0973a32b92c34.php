<?php

use Livewire\Volt\Component;
use Livewire\Attributes\Layout;
use Illuminate\Support\Facades\Session;
use SimpleSoftwareIO\QrCode\Facades\QrCode;
use App\Models\Berkas;

?>

<div>
    <div class="mb-4">
        <button wire:click="kembali" class="text-gray-700 underline">Kembali</button>
    </div>
    <div class="grid grid-cols-2 gap-3">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $data_berkas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berkas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $berkas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="flex gap-2 w-full px-4 py-3 border-2 border-gray-700">
                <div class="w-32 flex justify-center items-center">
                    <?php echo e(QrCode::size(120)->generate($item->kode_boks)); ?>

                </div>
                <div class="w-10 flex items-center justify-center bg-gray-300">
                    <div class="-rotate-90 font-semibold"><?php echo e($item->tahun); ?></div>
                </div>
                <div class="">
                    <div class="flex gap-2 mb-2">
                        <div class="w-16 flex justify-center">
                            <img src="<?php echo e(asset('assets/images/logo/kemenkeu-color.png')); ?>" width="60px">
                        </div>
                        <div>
                            <div class="text-sm uppercase">Kementerian Keuangan</div>
                            <div class="text-sm">Badan Pendidikan dan Pelatihan Keuangan</div>
                        </div>
                    </div>
                    <div class="text-xl font-semibold mb-1"><?php echo e($item->kode_boks); ?></div>
                    <div class="text-sm"><?php echo e($item->unit->nama_unit ?? '-'); ?></div>
                    <div class="text-sm"><?php echo e($item->kode_klas . ' - ' . $item->fungsi); ?></div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</div><?php /**PATH D:\laragon\www\rcms-livewire\resources\views\livewire/manajemenberkas/qrcode/qrcode-generator.blade.php ENDPATH**/ ?>