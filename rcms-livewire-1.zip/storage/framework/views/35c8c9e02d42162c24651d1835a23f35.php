<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
        <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/fontawesome/css/all.min.css')); ?>">

        <!-- Scripts -->
        <script src="<?php echo e(asset('assets/vendors/jquery/jquery-3.7.1.min.js')); ?>" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

        <style>
            body{
                background: rgb(89,124,131);
                background: linear-gradient(45deg, rgba(89,124,131,1) 0%, rgba(153,204,214,1) 100%);
            }
        </style>
    </head>
    <body class="font-sans antialiased">
        <div class="min-h-screen">
            <?php echo e($slot); ?>

        </div>

        <footer class="">
            <div class="mx-auto w-full max-w-screen-xl">
              <div class="flex justify-center">
                <div class="w-full text-white py-4">
                    <div class="py-3 mb-4 border-b border-gray-300 flex justify-center"><span class="italic">Copyright</span> &nbsp; <span><p>&copy; 2024 Tim Arsiparis BPPK</span></div>
                    <div class="mb-3 flex gap-3 justify-center">
                        <?php if (isset($component)) { $__componentOriginal006629c95188a2f50b43c627eb5878e5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal006629c95188a2f50b43c627eb5878e5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.my-warning-button','data' => ['class' => 'text-sm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('my-warning-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-sm']); ?>CONTACT US <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal006629c95188a2f50b43c627eb5878e5)): ?>
<?php $attributes = $__attributesOriginal006629c95188a2f50b43c627eb5878e5; ?>
<?php unset($__attributesOriginal006629c95188a2f50b43c627eb5878e5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal006629c95188a2f50b43c627eb5878e5)): ?>
<?php $component = $__componentOriginal006629c95188a2f50b43c627eb5878e5; ?>
<?php unset($__componentOriginal006629c95188a2f50b43c627eb5878e5); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal006629c95188a2f50b43c627eb5878e5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal006629c95188a2f50b43c627eb5878e5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.my-warning-button','data' => ['class' => 'text-sm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('my-warning-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-sm']); ?>GASS <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal006629c95188a2f50b43c627eb5878e5)): ?>
<?php $attributes = $__attributesOriginal006629c95188a2f50b43c627eb5878e5; ?>
<?php unset($__attributesOriginal006629c95188a2f50b43c627eb5878e5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal006629c95188a2f50b43c627eb5878e5)): ?>
<?php $component = $__componentOriginal006629c95188a2f50b43c627eb5878e5; ?>
<?php unset($__componentOriginal006629c95188a2f50b43c627eb5878e5); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal006629c95188a2f50b43c627eb5878e5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal006629c95188a2f50b43c627eb5878e5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.my-warning-button','data' => ['class' => 'text-sm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('my-warning-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-sm']); ?>RCMS <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal006629c95188a2f50b43c627eb5878e5)): ?>
<?php $attributes = $__attributesOriginal006629c95188a2f50b43c627eb5878e5; ?>
<?php unset($__attributesOriginal006629c95188a2f50b43c627eb5878e5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal006629c95188a2f50b43c627eb5878e5)): ?>
<?php $component = $__componentOriginal006629c95188a2f50b43c627eb5878e5; ?>
<?php unset($__componentOriginal006629c95188a2f50b43c627eb5878e5); ?>
<?php endif; ?>
                    </div>
                    <div class="text-center">UNIT KEARSIPAN II</div>
                    <div class="text-center text-lg">BADAN PENDIDIKAN DAN PELATIHAN KEUANGAN</div>
                    <div class="text-center text-sm">Telp. +62 21-739-4-666</div>
                </div>
            </div>
        </footer>
    </body>
</html>
<?php /**PATH D:\laragon\www\rcms-livewire\resources\views/layouts/layout-frontpage.blade.php ENDPATH**/ ?>