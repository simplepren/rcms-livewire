<?php

use Livewire\Volt\Component;
use Livewire\Attributes\Layout;
use Illuminate\Support\Facades\Session;
use SimpleSoftwareIO\QrCode\Facades\QrCode;
use Illuminate\Support\Str;
use App\Models\Berkas;
use App\Models\Unit;
use App\Models\Unitkearsipan;

?>

<div class="flex justify-center">
    <div style="width: 210mm; height: 297mm">
        <div class="mb-4">
            <button wire:click="kembali" class="text-gray-700 underline">Kembali</button>
        </div>
        <div class="grid grid-cols-2 gap-3">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $data_berkas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $berkas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="border-2 border-gray-400">
                    <div class="p-1 flex">
                        <div class="py-1 flex justify-center bg-teal-500" style="width: 120px; height: 138px">
                            <div>
                                <div class="bg-white w-28 h-28 py-1 flex justify-center">
                                    <div><?php echo e(QrCode::size(100)->generate($key)); ?></div>
                                </div>
                                <div class="flex justify-center items-center">
                                    <span class="text-white font-semibold text-sm"><?php echo e($key); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="pt-1 px-2" style="width: 260px">
                            <div class="flex justify-between">
                                <div><img src="<?php echo e(asset('assets/images/logo/kemenkeu-color.png')); ?>" width="40px"></div>
                                <div class="p-1 border border-gray-400">
                                    <span class="text-xl font-bold text-teal-500"><?php echo e(Str::substr($berkas[0]['kode_klas'], 0, 2)); ?></span>
                                </div>
                            </div>
                            <div class="mt-1">
                                <div>
                                    <div style="font-size: 13px">KEMENTERIAN KEUANGAN</div>
                                    <div style="font-size: 10px"><?php echo e($nama_uk); ?></div>
                                </div>
                            </div>
                            <div class="mt-4 flex gap-2">
                                <div class="border border-gray-400">
                                    <div class="flex px-1 justify-center">
                                        <span style="font-size: 9px">RC</span>
                                    </div>
                                    <div class="px-2 flex justify-center items-center">
                                        <span class="text-xl font-bold text-teal-500"><?php echo e($berkas[0]['lokasi_rc']); ?></span>
                                    </div>
                                </div>
                                <div class="border border-gray-400">
                                    <div class="flex px-1 justify-center">
                                        <span style="font-size: 9px">Ruang</span>
                                    </div>
                                    <div class="px-2 flex justify-center items-center">
                                        <span class="text-xl font-bold text-teal-500"><?php echo e($berkas[0]['ruang']); ?></span>
                                    </div>
                                </div>
                                <div class="border border-gray-400">
                                    <div class="flex px-1 justify-center">
                                        <span style="font-size: 9px">Rak</span>
                                    </div>
                                    <div class="px-2 flex justify-center items-center">
                                        <span class="text-xl font-bold text-teal-500"><?php echo e($berkas[0]['rak']); ?></span>
                                    </div>
                                </div>
                                <div class="border border-gray-400">
                                    <div class="flex px-1 justify-center">
                                        <span style="font-size: 9px">Boks</span>
                                    </div>
                                    <div class="px-2 flex justify-center items-center">
                                        <span class="text-xl font-bold text-teal-500"><?php echo e($berkas[0]['boks']); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>
</div><?php /**PATH D:\laragon\www\rcms-livewire\resources\views\livewire/manajemenberkas/qrcode/qrcode-generator-new.blade.php ENDPATH**/ ?>