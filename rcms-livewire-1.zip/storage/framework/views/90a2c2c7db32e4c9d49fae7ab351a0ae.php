<div>
    <div wire:loading class="fixed left-0 top-0 bg-white opacity-75 text-center w-full h-full" style="z-index: 51">
        <div class="min-h-full flex items-center justify-center">
            <div role="status">
                <svg aria-hidden="true" class="w-12 h-12 text-gray-200 animate-spin dark:text-gray-600 fill-blue-600" viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z" fill="currentColor"/><path d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z" fill="currentFill"/></svg>
                <span class="sr-only">Loading...</span>
            </div>
        </div>
    </div>
    <div class="flex justify-between px-4">
        <div class="p-2"><span class="text-xl text-gray-600 font-semibold">DAFTAR USER</span></div>
        <div class="p-2 md:block hidden">
            <nav class="flex" aria-label="Breadcrumb">
                <ol class="inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse">
                  <li class="inline-flex items-center">
                    <a href="#" class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600 dark:text-gray-400 dark:hover:text-white">
                        <svg class="w-3 h-3 me-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                            <path d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z"/>
                        </svg>
                      Home
                    </a>
                  </li>
                  <li aria-current="page">
                    <div class="flex items-center">
                      <svg class="rtl:rotate-180 w-3 h-3 text-gray-400 mx-1" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 9 4-4-4-4"/>
                      </svg>
                      <span class="ms-1 text-sm font-medium text-gray-500 md:ms-2 dark:text-gray-400">Setup User</span>
                    </div>
                  </li>
                </ol>
            </nav>
        </div>
    </div>
    <div class="p-4 bg-white rounded-sm">
        <div class="mb-3">
            <?php if (isset($component)) { $__componentOriginalb996e6c8394fd50075901e9047373063 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb996e6c8394fd50075901e9047373063 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.my-default-button','data' => ['class' => 'text-sm','wire:click' => 'tambahUser']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('my-default-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-sm','wire:click' => 'tambahUser']); ?>Tambah User <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb996e6c8394fd50075901e9047373063)): ?>
<?php $attributes = $__attributesOriginalb996e6c8394fd50075901e9047373063; ?>
<?php unset($__attributesOriginalb996e6c8394fd50075901e9047373063); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb996e6c8394fd50075901e9047373063)): ?>
<?php $component = $__componentOriginalb996e6c8394fd50075901e9047373063; ?>
<?php unset($__componentOriginalb996e6c8394fd50075901e9047373063); ?>
<?php endif; ?>
        </div>
        <div class="mb-4">
            <div class="flex justify-between gap-4">
                <div class="md:flex md:gap-4 hidden">
                    <div>
                        <select wire:model="perPage" class="input input-bordered">
                            <option value="10">10</option>
                            <option value="20">20</option>
                            <option value="50">50</option>
                        </select>
                    </div>
                    <div class="flex items-center">
                        <span class="text-sm">Items display</span>
                    </div>
                </div>
                <div>
                    <input wire:model.live.debounce.350ms="search" type="text" class="input input-bordered" placeholder="Cari user...">
                </div>
            </div>
        </div>
        <div class="overflow-x-auto">
            <table class="table-hover">
                <thead>
                    <tr>
                        <th style="width: 25px">No.</th>
                        <th>Nama User</th>
                        <th>NIP</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Unit Kearsipan</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $data_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($item->name); ?></td>
                            <td class="text-center"><?php echo e($item->nip); ?></td>
                            <td class="text-center"><?php echo e($item->email); ?></td>
                            <td class="text-center"><?php echo e($item->role); ?></td>
                            <td class="text-center"><?php echo e($item->unitKearsipan->nama_unit); ?></td>
                            <td class="md:flex md:justify-center gap-1">
                                <?php if (isset($component)) { $__componentOriginal006629c95188a2f50b43c627eb5878e5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal006629c95188a2f50b43c627eb5878e5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.my-warning-button','data' => ['wire:click' => 'editUser('.e($item->id).')','dataTooltipTarget' => 'tooltipEdit('.e($item->id).')','class' => 'btn btn-primary btn-sm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('my-warning-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'editUser('.e($item->id).')','data-tooltip-target' => 'tooltipEdit('.e($item->id).')','class' => 'btn btn-primary btn-sm']); ?><i class="fa fa-pencil"></i> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal006629c95188a2f50b43c627eb5878e5)): ?>
<?php $attributes = $__attributesOriginal006629c95188a2f50b43c627eb5878e5; ?>
<?php unset($__attributesOriginal006629c95188a2f50b43c627eb5878e5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal006629c95188a2f50b43c627eb5878e5)): ?>
<?php $component = $__componentOriginal006629c95188a2f50b43c627eb5878e5; ?>
<?php unset($__componentOriginal006629c95188a2f50b43c627eb5878e5); ?>
<?php endif; ?>
                                    <div id="tooltipEdit(<?php echo e($item->id); ?>)" role="tooltip" class="absolute z-10 invisible inline-block px-3 py-2 text-sm font-medium text-white transition-opacity duration-300 bg-gray-900 rounded-lg shadow-sm opacity-0 tooltip dark:bg-gray-700">
                                        Edit
                                        <div class="tooltip-arrow" data-popper-arrow></div>
                                    </div>
                                <?php if (isset($component)) { $__componentOriginalfc9b87891243f848f0cd53511c5006ce = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfc9b87891243f848f0cd53511c5006ce = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.my-danger-button','data' => ['wire:click' => 'hapusUser('.e($item->id).')','class' => 'text-xs','dataTooltipTarget' => 'tooltipHapus('.e($item->id).')']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('my-danger-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'hapusUser('.e($item->id).')','class' => 'text-xs','data-tooltip-target' => 'tooltipHapus('.e($item->id).')']); ?><i class="fa fa-trash-can"></i> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfc9b87891243f848f0cd53511c5006ce)): ?>
<?php $attributes = $__attributesOriginalfc9b87891243f848f0cd53511c5006ce; ?>
<?php unset($__attributesOriginalfc9b87891243f848f0cd53511c5006ce); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfc9b87891243f848f0cd53511c5006ce)): ?>
<?php $component = $__componentOriginalfc9b87891243f848f0cd53511c5006ce; ?>
<?php unset($__componentOriginalfc9b87891243f848f0cd53511c5006ce); ?>
<?php endif; ?>
                                    <div id="tooltipHapus(<?php echo e($item->id); ?>)" role="tooltip" class="absolute z-10 invisible inline-block px-3 py-2 text-sm font-medium text-white transition-opacity duration-300 bg-gray-900 rounded-lg shadow-sm opacity-0 tooltip dark:bg-gray-700">
                                        Hapus
                                        <div class="tooltip-arrow" data-popper-arrow></div>
                                    </div>
                                <?php if (isset($component)) { $__componentOriginalc91e854f1025e34bc07054bf856a8574 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc91e854f1025e34bc07054bf856a8574 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.my-success-button','data' => ['wire:click' => 'resetUser('.e($item->id).')','class' => 'text-xs','dataTooltipTarget' => 'isiBerkas('.e($item->id).')']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('my-success-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'resetUser('.e($item->id).')','class' => 'text-xs','data-tooltip-target' => 'isiBerkas('.e($item->id).')']); ?><i class="fa-solid fa-key"></i> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc91e854f1025e34bc07054bf856a8574)): ?>
<?php $attributes = $__attributesOriginalc91e854f1025e34bc07054bf856a8574; ?>
<?php unset($__attributesOriginalc91e854f1025e34bc07054bf856a8574); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc91e854f1025e34bc07054bf856a8574)): ?>
<?php $component = $__componentOriginalc91e854f1025e34bc07054bf856a8574; ?>
<?php unset($__componentOriginalc91e854f1025e34bc07054bf856a8574); ?>
<?php endif; ?>
                                    <div id="isiBerkas(<?php echo e($item->id); ?>)" role="tooltip" class="absolute z-10 invisible inline-block px-3 py-2 text-sm font-medium text-white transition-opacity duration-300 bg-gray-900 rounded-lg shadow-sm opacity-0 tooltip dark:bg-gray-700">
                                        Reset Password
                                        <div class="tooltip-arrow" data-popper-arrow></div>
                                    </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center">Tidak ada data</td>
                        </tr>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </tbody>
            </table>
        </div>
        <div class="mt-3">
            <?php echo e($data_user->links()); ?>

        </div>
    </div>

    <!-- Modal tambah user -->
    <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['name' => 'modal-tambah-user','maxWidth' => '2xl','focusable' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'modal-tambah-user','maxWidth' => '2xl','focusable' => true]); ?>
        <div class="p-3 flex justify-center bg-sky-700">
            <div class="text-xl font-semibold text-white">TAMBAH USER</div>
        </div>
        <div class="px-6 py-4">
            <form wire:submit.prevent="formTambahUser">
                <div class="flex w-full mb-2">
                    <div class="w-1/4 flex items-center">Nama Lengkap <span class="text-red-500"> *</span></div>
                    <div class="w-3/4">
                        <input type="text" wire:model="name" class="input input-bordered">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500 text-sm"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <div class="flex w-full mb-2">
                    <div class="w-1/4 flex items-center">Email <span class="text-red-500"> *</span></div>
                    <div class="w-3/4">
                        <input type="text" wire:model="email" class="input input-bordered">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500 text-sm"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <div class="flex w-full mb-2">
                    <div class="w-1/4 flex items-center">NIP <span class="text-red-500"> *</span></div>
                    <div class="w-3/4">
                        <input type="text" wire:model="nip" class="input input-bordered">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500 text-sm"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <div class="flex w-full mb-2">
                    <div class="w-1/4 flex items-center">Role <span class="text-red-500"> *</span></div>
                    <div class="w-3/4">
                        <select wire:model="role" class="input input-bordered">
                            <option value="">--Pilih Role--</option>
                            <option value="admin">Admin</option>
                            <option value="user">User</option>
                        </select>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500 text-sm"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <div class="flex w-full mb-2">
                    <div class="w-1/4 flex items-center">Unit Kearsipan <span class="text-red-500"> *</span></div>
                    <div class="w-3/4">
                        <select wire:model="kode_uk" class="input input-bordered">
                            <option value="">--Pilih UK--</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $data_uk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->kode_uk); ?>"><?php echo e($item->nama_unit); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </select>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['kode_uk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500 text-sm"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <div class="flex w-full mb-6">
                    <div class="w-1/4 flex items-center">Password <span class="text-red-500"> *</span></div>
                    <div class="w-3/4">
                        <input type="text" wire:model="password" class="input input-bordered">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500 text-sm"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <div class="flex justify-between">
                    <div>
                        <span class="text-red-500">* Wajib diisi</span>
                    </div>
                    <div class="flex gap-2 justify-end">
                        <?php if (isset($component)) { $__componentOriginal006629c95188a2f50b43c627eb5878e5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal006629c95188a2f50b43c627eb5878e5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.my-warning-button','data' => ['wire:click' => 'closeModalTambahUser']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('my-warning-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'closeModalTambahUser']); ?>Tutup <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal006629c95188a2f50b43c627eb5878e5)): ?>
<?php $attributes = $__attributesOriginal006629c95188a2f50b43c627eb5878e5; ?>
<?php unset($__attributesOriginal006629c95188a2f50b43c627eb5878e5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal006629c95188a2f50b43c627eb5878e5)): ?>
<?php $component = $__componentOriginal006629c95188a2f50b43c627eb5878e5; ?>
<?php unset($__componentOriginal006629c95188a2f50b43c627eb5878e5); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalb996e6c8394fd50075901e9047373063 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb996e6c8394fd50075901e9047373063 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.my-default-button','data' => ['type' => 'submit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('my-default-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit']); ?>Simpan <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb996e6c8394fd50075901e9047373063)): ?>
<?php $attributes = $__attributesOriginalb996e6c8394fd50075901e9047373063; ?>
<?php unset($__attributesOriginalb996e6c8394fd50075901e9047373063); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb996e6c8394fd50075901e9047373063)): ?>
<?php $component = $__componentOriginalb996e6c8394fd50075901e9047373063; ?>
<?php unset($__componentOriginalb996e6c8394fd50075901e9047373063); ?>
<?php endif; ?>
                    </div>
                </div>
            </form>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
    <!-- Modal tambah user -->

    <!-- Modal Edit user -->
    <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['name' => 'modal-edit-user','maxWidth' => '2xl','focusable' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'modal-edit-user','maxWidth' => '2xl','focusable' => true]); ?>
        <div class="p-3 flex justify-center bg-sky-700">
            <div class="text-xl font-semibold text-white">EDIT USER</div>
        </div>
        <div class="px-6 py-4">
            <form wire:submit.prevent="formEditUser">
                <div class="flex w-full mb-2">
                    <div class="w-1/4 flex items-center">Nama Lengkap <span class="text-red-500"> *</span></div>
                    <div class="w-3/4">
                        <input type="text" wire:model="name" class="input input-bordered">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500 text-sm"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <div class="flex w-full mb-2">
                    <div class="w-1/4 flex items-center">Email <span class="text-red-500"> *</span></div>
                    <div class="w-3/4">
                        <input type="text" wire:model="email" class="input input-bordered">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500 text-sm"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <div class="flex w-full mb-2">
                    <div class="w-1/4 flex items-center">NIP <span class="text-red-500"> *</span></div>
                    <div class="w-3/4">
                        <input type="text" wire:model="nip" class="input input-bordered">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500 text-sm"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <div class="flex w-full mb-2">
                    <div class="w-1/4 flex items-center">Role <span class="text-red-500"> *</span></div>
                    <div class="w-3/4">
                        <select wire:model="role" class="input input-bordered">
                            <option value="">--Pilih Role--</option>
                            <option value="admin">Admin</option>
                            <option value="user">User</option>
                        </select>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500 text-sm"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <div class="flex w-full mb-2">
                    <div class="w-1/4 flex items-center">Unit Kearsipan <span class="text-red-500"> *</span></div>
                    <div class="w-3/4">
                        <select wire:model="kode_uk" class="input input-bordered">
                            <option value="">--Pilih UK--</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $data_uk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->kode_uk); ?>"><?php echo e($item->nama_unit); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </select>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['kode_uk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500 text-sm"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <div class="flex w-full mb-6">
                    <div class="w-1/4 flex items-center">Password <span class="text-red-500"> *</span></div>
                    <div class="w-3/4">
                        <input type="text" wire:model="password" class="input input-bordered" placeholder="Kosongkan jika tidak diubah">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500 text-sm"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <div class="flex justify-between">
                    <div>
                        <span class="text-red-500">* Wajib diisi</span>
                    </div>
                    <div class="flex gap-2 justify-end">
                        <?php if (isset($component)) { $__componentOriginal006629c95188a2f50b43c627eb5878e5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal006629c95188a2f50b43c627eb5878e5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.my-warning-button','data' => ['wire:click' => 'closeModalEditUser']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('my-warning-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'closeModalEditUser']); ?>Tutup <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal006629c95188a2f50b43c627eb5878e5)): ?>
<?php $attributes = $__attributesOriginal006629c95188a2f50b43c627eb5878e5; ?>
<?php unset($__attributesOriginal006629c95188a2f50b43c627eb5878e5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal006629c95188a2f50b43c627eb5878e5)): ?>
<?php $component = $__componentOriginal006629c95188a2f50b43c627eb5878e5; ?>
<?php unset($__componentOriginal006629c95188a2f50b43c627eb5878e5); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalb996e6c8394fd50075901e9047373063 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb996e6c8394fd50075901e9047373063 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.my-default-button','data' => ['type' => 'submit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('my-default-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit']); ?>Simpan <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb996e6c8394fd50075901e9047373063)): ?>
<?php $attributes = $__attributesOriginalb996e6c8394fd50075901e9047373063; ?>
<?php unset($__attributesOriginalb996e6c8394fd50075901e9047373063); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb996e6c8394fd50075901e9047373063)): ?>
<?php $component = $__componentOriginalb996e6c8394fd50075901e9047373063; ?>
<?php unset($__componentOriginalb996e6c8394fd50075901e9047373063); ?>
<?php endif; ?>
                    </div>
                </div>
            </form>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
    <!-- Modal edit user -->

    <!-- Modal hapus user -->
    <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['name' => 'modal-hapus-user','maxWidth' => 'lg','focusable' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'modal-hapus-user','max-width' => 'lg','focusable' => true]); ?>
        <div class="p-3 flex justify-center bg-red-700">
            <div class="text-xl font-semibold text-white">HAPUS USER</div>
        </div>
        <div class="px-6 py-4">
            <form wire:submit.prevent="formHapusUser">
                <div class="text-xl font-semibold mb-3 text-center">Konfirmasi!!</div>
                <div class="text-center mb-6">Anda yakin akan menghapus user ini?</div>
                <input type="text" wire:model="id_user" class="hidden">
                <div class="flex justify-end gap-2">
                    <?php if (isset($component)) { $__componentOriginal006629c95188a2f50b43c627eb5878e5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal006629c95188a2f50b43c627eb5878e5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.my-warning-button','data' => ['class' => 'btn-sm','wire:click.prevent' => 'closeModalHapus']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('my-warning-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'btn-sm','wire:click.prevent' => 'closeModalHapus']); ?>Close <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal006629c95188a2f50b43c627eb5878e5)): ?>
<?php $attributes = $__attributesOriginal006629c95188a2f50b43c627eb5878e5; ?>
<?php unset($__attributesOriginal006629c95188a2f50b43c627eb5878e5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal006629c95188a2f50b43c627eb5878e5)): ?>
<?php $component = $__componentOriginal006629c95188a2f50b43c627eb5878e5; ?>
<?php unset($__componentOriginal006629c95188a2f50b43c627eb5878e5); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalfc9b87891243f848f0cd53511c5006ce = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfc9b87891243f848f0cd53511c5006ce = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.my-danger-button','data' => ['class' => 'btn-sm','type' => 'submit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('my-danger-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'btn-sm','type' => 'submit']); ?>Submit <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfc9b87891243f848f0cd53511c5006ce)): ?>
<?php $attributes = $__attributesOriginalfc9b87891243f848f0cd53511c5006ce; ?>
<?php unset($__attributesOriginalfc9b87891243f848f0cd53511c5006ce); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfc9b87891243f848f0cd53511c5006ce)): ?>
<?php $component = $__componentOriginalfc9b87891243f848f0cd53511c5006ce; ?>
<?php unset($__componentOriginalfc9b87891243f848f0cd53511c5006ce); ?>
<?php endif; ?>
                </div>
            </form>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
    <!-- Modal hapus user -->

    <!-- Modal reset password -->
    <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['name' => 'modal-reset-user','maxWidth' => 'xl','focusable' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'modal-reset-user','max-width' => 'xl','focusable' => true]); ?>
        <div class="p-3 flex justify-center bg-sky-700">
            <div class="text-xl font-semibold text-white">RESET PASSWORD</div>
        </div>
        <div class="px-6 py-4">
            <form wire:submit.prevent="formResetUser">
                <div class="flex w-full mb-6">
                    <div class="w-1/4 flex items-center">Password Baru<span class="text-red-500"> *</span></div>
                    <div class="w-3/4">
                        <input type="text" wire:model="id_user" class="hidden">
                        <input type="text" wire:model="new_password" class="input input-bordered">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500 text-sm"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <div class="flex justify-between">
                    <div>
                        <span class="text-red-500">* Wajib diisi</span>
                    </div>
                    <div class="flex gap-2 justify-end">
                        <?php if (isset($component)) { $__componentOriginal006629c95188a2f50b43c627eb5878e5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal006629c95188a2f50b43c627eb5878e5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.my-warning-button','data' => ['wire:click' => 'closeModalResetUser']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('my-warning-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'closeModalResetUser']); ?>Tutup <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal006629c95188a2f50b43c627eb5878e5)): ?>
<?php $attributes = $__attributesOriginal006629c95188a2f50b43c627eb5878e5; ?>
<?php unset($__attributesOriginal006629c95188a2f50b43c627eb5878e5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal006629c95188a2f50b43c627eb5878e5)): ?>
<?php $component = $__componentOriginal006629c95188a2f50b43c627eb5878e5; ?>
<?php unset($__componentOriginal006629c95188a2f50b43c627eb5878e5); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalb996e6c8394fd50075901e9047373063 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb996e6c8394fd50075901e9047373063 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.my-default-button','data' => ['type' => 'submit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('my-default-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit']); ?>Simpan <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb996e6c8394fd50075901e9047373063)): ?>
<?php $attributes = $__attributesOriginalb996e6c8394fd50075901e9047373063; ?>
<?php unset($__attributesOriginalb996e6c8394fd50075901e9047373063); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb996e6c8394fd50075901e9047373063)): ?>
<?php $component = $__componentOriginalb996e6c8394fd50075901e9047373063; ?>
<?php unset($__componentOriginalb996e6c8394fd50075901e9047373063); ?>
<?php endif; ?>
                    </div>
                </div>
            </form>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
    <!-- Modal reset password -->

</div>
<?php /**PATH D:\laragon\www\rcms-livewire\resources\views/livewire/setup/user/index.blade.php ENDPATH**/ ?>