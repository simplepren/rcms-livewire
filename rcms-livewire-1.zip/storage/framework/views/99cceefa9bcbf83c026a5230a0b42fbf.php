<button <?php echo e($attributes->merge(['type' => 'button', 'class' => 'px-3 py-2 font-medium text-center text-white bg-blue-800 rounded-lg hover:bg-blue-900 focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH D:\laragon\www\rcms-livewire\resources\views/components/my-info-button.blade.php ENDPATH**/ ?>