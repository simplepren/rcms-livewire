<button <?php echo e($attributes->merge(['type' => 'button', 'class' => 'px-3 py-2 font-medium text-center text-white bg-slate-400 rounded-lg dark:bg-gray-300  dark:text-gray-800'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH D:\laragon\www\rcms-livewire\resources\views/components/my-disabled-button.blade.php ENDPATH**/ ?>