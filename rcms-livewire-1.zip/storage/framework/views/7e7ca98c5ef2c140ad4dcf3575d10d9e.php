<?php

use Livewire\Volt\Component;
use Livewire\Attributes\Layout;
use App\Models\Peminjaman;
use App\Models\Berkas;

?>

<div class="flex justify-center">
    <div class="p-3" style="width: 210mm; height: 297mm"> <!-- A4 docs 210mm x 297mm -->
        <div class="">
            <div class="mb-1 w-48 h-14 text-center bg-slate-700 text-white text-xl font-bold p-4">BUKTI PINJAM</div>
            <div class="text-sm mb-1">Kode: <?php echo e($id_peminjaman); ?></div>
        </div>
        <div class="mt-4 mb-3 border-b-2 border-gray-400"></div>
        <div>
            <div class="mb-1 italic font-semibold text-lg text-amber-700">Peminjam</div>
            <div class="text-2xl"><?php echo e($nama); ?></div>
            <div class="text-sm"><?php echo e($unit); ?></div>
        </div>
        <div class="mt-10">
            <table class="w-full">
                <thead class="text-sm text-amber-700">
                    <tr class="border-b-2 border-gray-300">
                        <th class="py-1">No. Berkas</th>
                        <th class="">Uraian Berkas</th>
                        <th>Keperluan</th>
                        <th>Tgl Pinjam</th>
                        <th>Tgl Kembali</th>
                    </tr>
                </thead>
                <tbody>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $data_pinjam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-sm border-b-2 border-gray-300">
                            <td class="text-center h-8"><?php echo e($item->detailBerkas->no_berkas ?? '-'); ?></td>
                            <td><?php echo e($item->uraian_berkas); ?></td>
                            <td class="text-center"><?php echo e($item->keperluan); ?></td>
                            <td class="text-center"><?php echo e($item->tgl_pinjam); ?></td>
                            <td class="text-center"><?php echo e($item->tgl_kembali); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </tbody>
            </table>
        </div>
        <div class="mt-10">
            <div class="grid grid-cols-2">
                <div class="flex justify-center">
                    <div>
                        <div class="text-center text-sm mb-3">Peminjam</div>
                        <!--[if BLOCK]><![endif]--><?php if($esign_peminjam): ?>
                            <div class="h-22"><img src="<?php echo e(asset('assets/images/signature/'.$esign_peminjam)); ?>" alt="" width="170px"></div>
                        <?php else: ?>
                            <div class="h-22"><img src="<?php echo e(asset('assets/images/signature/no-signature.png')); ?>" alt="" width="170px"></div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <div class="text-center mt-2 text-sm"><?php echo e($nama); ?></div>
                    </div>
                </div>
                <div class="flex justify-center">
                    <div>
                        <div class="text-center text-sm mb-3">Petugas/Arsiparis</div>
                        <!--[if BLOCK]><![endif]--><?php if($esign_petugas): ?>
                            <div class="h-22"><img src="<?php echo e(asset('assets/images/signature/'.$esign_petugas)); ?>" alt="" width="170px"></div>
                        <?php else: ?>
                            <div class="h-22"><img src="<?php echo e(asset('assets/images/signature/no-signature.png')); ?>" alt="" width="170px"></div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <div class="text-center mt-2 text-sm"><?php echo e($nama_petugas); ?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\laragon\www\rcms-livewire\resources\views\livewire/layanan/peminjaman/cetak.blade.php ENDPATH**/ ?>