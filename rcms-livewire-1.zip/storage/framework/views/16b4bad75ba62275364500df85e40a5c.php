<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />

        <!-- Styles -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <body class="antialiased font-sans">
        <div class="p-4">
            <div class="mb-4">
                <a href="<?php echo e(route('cetak-qrcode')); ?>" class="text-gray-700 underline">Kembali</a>
            </div>
            <div class="grid grid-cols-2 gap-3">
                <?php $__currentLoopData = $kode_boks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex gap-2 w-full px-4 py-3 border-2 border-gray-700">
                    <div class="w-32 flex justify-center items-center">
                        <?php echo e($qrcode); ?>

                    </div>
                    <div class="w-10 flex items-center justify-center bg-gray-300">
                        <div class="-rotate-90 font-semibold">2020</div>
                    </div>
                    <div class="">
                        <div class="flex gap-2 mb-2">
                            <div class="w-16 flex justify-center">
                                <img src="<?php echo e(asset('assets/images/logo/kemenkeu-color.png')); ?>" width="60px">
                            </div>
                            <div>
                                <div class="text-sm uppercase">Kementerian Keuangan</div>
                                <div class="text-sm">Badan Pendidikan dan Pelatihan Keuangan</div>
                            </div>
                        </div>
                        <div class="text-xl font-semibold mb-1"><?php echo e($item); ?></div>
                        <div class="text-sm">Sekretariat Badan</div>
                        <div class="text-sm">KU1.4 - Belanja/Pengeluaran Anggaran</div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </body>
</html>
<?php /**PATH D:\laragon\www\rcms-livewire\resources\views/qrcode.blade.php ENDPATH**/ ?>