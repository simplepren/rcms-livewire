<div>
    <div wire:loading class="fixed left-0 top-0 bg-white opacity-75 text-center w-full h-full" style="z-index: 51">
        <div class="min-h-full flex items-center justify-center">
            <div role="status">
                <svg aria-hidden="true" class="w-12 h-12 text-gray-200 animate-spin dark:text-gray-600 fill-blue-600" viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z" fill="currentColor"/><path d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z" fill="currentFill"/></svg>
                <span class="sr-only">Loading...</span>
            </div>
        </div>
    </div>
    <div class="mb-5">
        <?php if (isset($component)) { $__componentOriginalb996e6c8394fd50075901e9047373063 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb996e6c8394fd50075901e9047373063 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.my-default-button','data' => ['class' => 'text-sm','wire:click' => 'tambah']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('my-default-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-sm','wire:click' => 'tambah']); ?>Tambah Ruangan <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb996e6c8394fd50075901e9047373063)): ?>
<?php $attributes = $__attributesOriginalb996e6c8394fd50075901e9047373063; ?>
<?php unset($__attributesOriginalb996e6c8394fd50075901e9047373063); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb996e6c8394fd50075901e9047373063)): ?>
<?php $component = $__componentOriginalb996e6c8394fd50075901e9047373063; ?>
<?php unset($__componentOriginalb996e6c8394fd50075901e9047373063); ?>
<?php endif; ?>
    </div>
    <div class="mb-5">
        <div class="flex justify-between">
            <div class="md:flex md:gap-3 hidden">
                <div>
                    <select wire:model.live="perPage" class="input input-bordered">
                        <option value="10">10</option>
                        <option value="20">20</option>
                        <option value="50">50</option>
                    </select>
                </div>
                <div class="flex items-center">
                    <span>Items display</span>
                </div>
            </div>
            <div class="md:w-1/4 w-full">
                <input wire:model.live.debounce.350ms="search" type="text" class="input input-bordered" placeholder="Cari ruangan..." wire:model="search">
            </div>
        </div>
    </div>
    <div class="overflow-x-auto">
        <table class="table-hover">
            <thead>
                <tr>
                    <th style="width: 25px">No.</th>
                    <th>Kode RC</th>
                    <th>Kode Ruangan</th>
                    <th>Nama Ruangan</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $data_ruangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td class="text-center"><?php echo e($item->kode_rc); ?></td>
                        <td class="text-center"><?php echo e($item->kode_ruang); ?></td>
                        <td class="text-center"><?php echo e($item->nama_ruang); ?></td>
                        <td class="md:flex md:justify-center gap-1">
                            <?php if (isset($component)) { $__componentOriginal006629c95188a2f50b43c627eb5878e5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal006629c95188a2f50b43c627eb5878e5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.my-warning-button','data' => ['wire:click' => 'editRuangan('.e($item->id).')','dataTooltipTarget' => 'tooltipEdit('.e($item->id).')','class' => 'btn btn-primary btn-sm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('my-warning-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'editRuangan('.e($item->id).')','data-tooltip-target' => 'tooltipEdit('.e($item->id).')','class' => 'btn btn-primary btn-sm']); ?><i class="fa fa-pencil"></i> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal006629c95188a2f50b43c627eb5878e5)): ?>
<?php $attributes = $__attributesOriginal006629c95188a2f50b43c627eb5878e5; ?>
<?php unset($__attributesOriginal006629c95188a2f50b43c627eb5878e5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal006629c95188a2f50b43c627eb5878e5)): ?>
<?php $component = $__componentOriginal006629c95188a2f50b43c627eb5878e5; ?>
<?php unset($__componentOriginal006629c95188a2f50b43c627eb5878e5); ?>
<?php endif; ?>
                                <div id="tooltipEdit(<?php echo e($item->id); ?>)" role="tooltip" class="absolute z-10 invisible inline-block px-3 py-2 text-sm font-medium text-white transition-opacity duration-300 bg-gray-900 rounded-lg shadow-sm opacity-0 tooltip dark:bg-gray-700">
                                    Edit
                                    <div class="tooltip-arrow" data-popper-arrow></div>
                                </div>
                            <?php if (isset($component)) { $__componentOriginalfc9b87891243f848f0cd53511c5006ce = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfc9b87891243f848f0cd53511c5006ce = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.my-danger-button','data' => ['wire:click' => 'hapusRuangan('.e($item->id).')','class' => 'text-xs','dataTooltipTarget' => 'tooltipHapus('.e($item->id).')']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('my-danger-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'hapusRuangan('.e($item->id).')','class' => 'text-xs','data-tooltip-target' => 'tooltipHapus('.e($item->id).')']); ?><i class="fa fa-trash-can"></i> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfc9b87891243f848f0cd53511c5006ce)): ?>
<?php $attributes = $__attributesOriginalfc9b87891243f848f0cd53511c5006ce; ?>
<?php unset($__attributesOriginalfc9b87891243f848f0cd53511c5006ce); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfc9b87891243f848f0cd53511c5006ce)): ?>
<?php $component = $__componentOriginalfc9b87891243f848f0cd53511c5006ce; ?>
<?php unset($__componentOriginalfc9b87891243f848f0cd53511c5006ce); ?>
<?php endif; ?>
                                <div id="tooltipHapus(<?php echo e($item->id); ?>)" role="tooltip" class="absolute z-10 invisible inline-block px-3 py-2 text-sm font-medium text-white transition-opacity duration-300 bg-gray-900 rounded-lg shadow-sm opacity-0 tooltip dark:bg-gray-700">
                                    Hapus
                                    <div class="tooltip-arrow" data-popper-arrow></div>
                                </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center">Tidak ada data</td>
                    </tr>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>
    </div>
    <div class="mt-3">
        <?php echo e($data_ruangan->links()); ?>

    </div>

    <!-- Modal Tambah Ruangan-->
    <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['name' => 'modal-tambah-ruangan','maxWidth' => '2xl']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'modal-tambah-ruangan','maxWidth' => '2xl']); ?>
        <div class="p-3 flex justify-center bg-sky-700">
            <div class="text-xl font-semibold text-white">TAMBAH RUANGAN</div>
        </div>
        <div class="px-6 py-4">
            <form wire:submit.prevent="formTambahRuangan">
                <div class="flex w-full mb-2">
                    <div class="w-1/4 flex items-center">Records Center <span class="text-red-500"> *</span></div>
                    <div class="w-3/4">
                        <select wire:model="kode_rc" class="input input-bordered">
                            <option value="">--Pilih RC--</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $data_rc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->kode_rc); ?>"><?php echo e($item->nama_rc); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </select>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['kode_rc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500 text-sm"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <div class="flex w-full mb-5">
                    <div class="w-1/4 flex items-center">Kode Ruangan <span class="text-red-500"> *</span></div>
                    <div class="w-3/4">
                        <input type="text" wire:model="kode_ruang" class="input input-bordered">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['kode_ruang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500 text-sm"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <div class="flex w-full mb-5">
                    <div class="w-1/4 flex items-center">Nama Ruangan</div>
                    <div class="w-3/4">
                        <input type="text" wire:model="nama_ruang" class="input input-bordered">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nama_ruang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500 text-sm"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <div class="flex justify-between">
                    <div>
                        <span class="text-red-500">* Wajib diisi</span>
                    </div>
                    <div class="flex gap-2 justify-end">
                        <?php if (isset($component)) { $__componentOriginal006629c95188a2f50b43c627eb5878e5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal006629c95188a2f50b43c627eb5878e5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.my-warning-button','data' => ['wire:click' => 'closeModalRuangan']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('my-warning-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'closeModalRuangan']); ?>Tutup <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal006629c95188a2f50b43c627eb5878e5)): ?>
<?php $attributes = $__attributesOriginal006629c95188a2f50b43c627eb5878e5; ?>
<?php unset($__attributesOriginal006629c95188a2f50b43c627eb5878e5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal006629c95188a2f50b43c627eb5878e5)): ?>
<?php $component = $__componentOriginal006629c95188a2f50b43c627eb5878e5; ?>
<?php unset($__componentOriginal006629c95188a2f50b43c627eb5878e5); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalb996e6c8394fd50075901e9047373063 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb996e6c8394fd50075901e9047373063 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.my-default-button','data' => ['type' => 'submit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('my-default-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit']); ?>Simpan <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb996e6c8394fd50075901e9047373063)): ?>
<?php $attributes = $__attributesOriginalb996e6c8394fd50075901e9047373063; ?>
<?php unset($__attributesOriginalb996e6c8394fd50075901e9047373063); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb996e6c8394fd50075901e9047373063)): ?>
<?php $component = $__componentOriginalb996e6c8394fd50075901e9047373063; ?>
<?php unset($__componentOriginalb996e6c8394fd50075901e9047373063); ?>
<?php endif; ?>
                    </div>
                </div>
            </form>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
    <!-- Modal Tambah Ruangan-->

    <!-- Modal Edit Ruangan-->
    <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['name' => 'modal-edit-ruangan','maxWidth' => '2xl']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'modal-edit-ruangan','maxWidth' => '2xl']); ?>
        <div class="p-3 flex justify-center bg-sky-700">
            <div class="text-xl font-semibold text-white">EDIT RUANGAN</div>
        </div>
        <div class="px-6 py-4">
            <form wire:submit.prevent="formEditRuangan">
                <div class="flex w-full mb-2">
                    <div class="w-1/4 flex items-center">Records Center <span class="text-red-500"> *</span></div>
                    <div class="w-3/4">
                        <select wire:model="kode_rc" class="input input-bordered">
                            <option value="">--Pilih RC--</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $data_rc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->kode_rc); ?>"><?php echo e($item->nama_rc); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </select>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['kode_rc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500 text-sm"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <div class="flex w-full mb-2">
                    <div class="w-1/4 flex items-center">Kode Ruangan <span class="text-red-500"> *</span></div>
                    <div class="w-3/4">
                        <input type="text" wire:model="kode_ruang" class="input input-bordered">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['kode_ruang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500 text-sm"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <div class="flex w-full mb-2">
                    <div class="w-1/4 flex items-center">Nama Ruangan</div>
                    <div class="w-3/4">
                        <input type="text" wire:model="nama_ruang" class="input input-bordered">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nama_ruang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500 text-sm"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <div class="flex w-full mb-5">
                    <div class="w-1/4 flex items-center">Ubah data ruangan pada berkas?</div>
                    <div class="w-3/4 flex">
                        <div>
                            <input wire:model="ubah_data" id="checkbox" type="checkbox" value="" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600">
                        </div>
                        <div>
                            <label for="checkbox" class="ms-2 text-sm font-medium text-orange-700 dark:text-gray-300">Ya (Data ruangan pada seluruh berkas akan berubah)</label>
                        </div>
                    </div>
                </div>
                <div class="flex justify-between">
                    <div>
                        <span class="text-red-500">* Wajib diisi</span>
                    </div>
                    <div class="flex gap-2 justify-end">
                        <?php if (isset($component)) { $__componentOriginal006629c95188a2f50b43c627eb5878e5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal006629c95188a2f50b43c627eb5878e5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.my-warning-button','data' => ['wire:click' => 'closeModalEditRuangan']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('my-warning-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'closeModalEditRuangan']); ?>Tutup <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal006629c95188a2f50b43c627eb5878e5)): ?>
<?php $attributes = $__attributesOriginal006629c95188a2f50b43c627eb5878e5; ?>
<?php unset($__attributesOriginal006629c95188a2f50b43c627eb5878e5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal006629c95188a2f50b43c627eb5878e5)): ?>
<?php $component = $__componentOriginal006629c95188a2f50b43c627eb5878e5; ?>
<?php unset($__componentOriginal006629c95188a2f50b43c627eb5878e5); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalb996e6c8394fd50075901e9047373063 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb996e6c8394fd50075901e9047373063 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.my-default-button','data' => ['type' => 'submit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('my-default-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit']); ?>Simpan <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb996e6c8394fd50075901e9047373063)): ?>
<?php $attributes = $__attributesOriginalb996e6c8394fd50075901e9047373063; ?>
<?php unset($__attributesOriginalb996e6c8394fd50075901e9047373063); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb996e6c8394fd50075901e9047373063)): ?>
<?php $component = $__componentOriginalb996e6c8394fd50075901e9047373063; ?>
<?php unset($__componentOriginalb996e6c8394fd50075901e9047373063); ?>
<?php endif; ?>
                    </div>
                </div>
            </form>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
    <!-- Modal Edit Ruangan-->

    <!-- Modal Hapus Ruangan-->
    <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['name' => 'modal-hapus-ruangan','maxWidth' => 'lg']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'modal-hapus-ruangan','maxWidth' => 'lg']); ?>
        <div class="p-3 flex justify-center bg-red-700">
            <div class="text-xl font-semibold text-white">HAPUS RUANGAN</div>
        </div>
        <div class="px-6 py-4">
            <form wire:submit.prevent="formHapusRuangan">
                <div class="font-semibold mb-3 text-center">Konfirmasi!!</div>
                <div class="text-center mb-3">Anda yakin akan menghapus ruangan ini?</div>
                <input type="text" wire:model="id_ruangan" class="hidden">
                <div class="flex justify-center mb-6">
                    <div class="flex items-center">
                        <input wire:model="hapus_rak" id="checked-checkbox" type="checkbox" value="" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600">
                        <label for="checked-checkbox" class="ms-2 text-sm font-medium text-gray-900 dark:text-gray-300">Hapus Rak</label>
                    </div>
                </div>
                <div class="flex gap-4 justify-end">
                    <?php if (isset($component)) { $__componentOriginal006629c95188a2f50b43c627eb5878e5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal006629c95188a2f50b43c627eb5878e5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.my-warning-button','data' => ['wire:click' => 'closeModalHapusRuangan']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('my-warning-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'closeModalHapusRuangan']); ?>Close <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal006629c95188a2f50b43c627eb5878e5)): ?>
<?php $attributes = $__attributesOriginal006629c95188a2f50b43c627eb5878e5; ?>
<?php unset($__attributesOriginal006629c95188a2f50b43c627eb5878e5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal006629c95188a2f50b43c627eb5878e5)): ?>
<?php $component = $__componentOriginal006629c95188a2f50b43c627eb5878e5; ?>
<?php unset($__componentOriginal006629c95188a2f50b43c627eb5878e5); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalb996e6c8394fd50075901e9047373063 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb996e6c8394fd50075901e9047373063 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.my-default-button','data' => ['type' => 'submit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('my-default-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit']); ?>Submit <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb996e6c8394fd50075901e9047373063)): ?>
<?php $attributes = $__attributesOriginalb996e6c8394fd50075901e9047373063; ?>
<?php unset($__attributesOriginalb996e6c8394fd50075901e9047373063); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb996e6c8394fd50075901e9047373063)): ?>
<?php $component = $__componentOriginalb996e6c8394fd50075901e9047373063; ?>
<?php unset($__componentOriginalb996e6c8394fd50075901e9047373063); ?>
<?php endif; ?>
                </div>
            </form>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
    <!-- Modal Hapus Ruangan-->

</div>
<?php /**PATH D:\laragon\www\rcms-livewire\resources\views/livewire/sarpras/ruangan/index.blade.php ENDPATH**/ ?>