import 'flowbite';
import { initFlowbite } from 'flowbite';
import './bootstrap';

// Livewire.hook('morph.updated', ({ el, component }) => {
//     initFlowbite()
//  });
// document.addEventListener('livewire:navigated', () => {
//     initFlowbite();
// })
