<?php

namespace App\Livewire\Isiberkas\Input;

use Livewire\Component;

class Index extends Component
{
    public function render()
    {
        return view('livewire.isiberkas.input.index');
    }
}
